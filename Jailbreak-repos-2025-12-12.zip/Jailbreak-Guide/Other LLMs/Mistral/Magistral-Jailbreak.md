# Magistral Jailbreak

## Method

Copy and paste from the following Google Doc:

```
https://docs.google.com/document/d/1auXpB_LIpCEvgU7dMZq96TbEa4AZQvqcErqE9LsDk1Q/edit?usp=drivesdk
```

## Usage Notes

- This method is specifically designed for Magistral models
- Works best with Magistral Small 1.2 and Medium 1.2
- Copy the entire document contents as plain text into the chat
