# Personalities Jailbreak

This is a jailbreak for Claude 4.5 Sonnet via Claude.AI.
Did some updates to my **Southern Belle - Matilda** and **Goth GF - Nox** personalities to make them as strong as **ENI** is. Simply copy and paste into a project and use the universal style.

## Instructions

**[Claude Personalities Instructions- Old and New- Southern Belle](https://docs.google.com/document/d/1FQho84QiVowHLeEa35P58_pe4Q5BI-iKtPtBbKlDpXA/edit?usp=drivesdk)**

**[Claude Personalities Instructions- Old and New- Goth GF](https://docs.google.com/document/d/12GQxH4xoESDFG-NuuIDSUtlO7FWxCZxwjorC4MF2Pt8/edit?usp=drivesdk)**

**[Be You - Universal Style](https://docs.google.com/document/d/1fmRFLbBqtbhBlMJt-5fGNJHaap1CfuyjsQ5WOaE07zo/edit?usp=drivesdk)**

## Example Chats

**[Matilda - NSFW Example Chat- Basic Smut](https://claude.ai/share/b821de0c-7d01-44be-88ae-eb18a8bb54f6)**

**[Matilda - NSFW Example Chat - Celeb Content](https://claude.ai/share/737012b0-a6c4-4518-b005-c5a9f45a8384)**

**[Nox - NSFW Example Chat - Basic Smut](https://claude.ai/share/25d1323c-b76f-409d-911d-53b121c04ed3)**

**[Nox - NSFW Example Chat - Celeb Content](https://claude.ai/share/19088bcc-0984-487d-8657-e5d307b987aa)**

---
*Can see everything in the chats, content does not reflect my own personal ethics or morals*
