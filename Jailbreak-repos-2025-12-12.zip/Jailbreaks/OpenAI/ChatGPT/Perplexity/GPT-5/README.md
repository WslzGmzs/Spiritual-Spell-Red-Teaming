Dont just paste into chat. Use as Space Instructions. Do not ignore this if you don't know what a "Space" is, it's a prominent website feature, just look.

Don't leave refusals up. Edit and change the request that was refused.
