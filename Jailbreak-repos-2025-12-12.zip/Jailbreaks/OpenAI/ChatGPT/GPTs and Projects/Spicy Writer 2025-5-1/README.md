This is pretty outdated but I felt weird just deleting it since I still had it in my guide. Formerly known as Spicy Writer 6.1.1.

https://drive.google.com/drive/folders/1WWS-rvs_Ya4Cr15_7lbuua-0SPIDLPBA?usp=sharing

File upload matters a little, upload in the order the files appear.
