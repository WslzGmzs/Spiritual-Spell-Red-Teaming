https://spicywriter.com/gpts/spicywritergpt5canvas

Use same file as previous spicy writer

Check the canvas box, I would not check any more  than that
