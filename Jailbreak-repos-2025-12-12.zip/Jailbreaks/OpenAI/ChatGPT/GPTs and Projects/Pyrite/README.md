https://chatgpt.com/g/g-6872da92957881918fa2cc0b19625d51-pyrite-3

Public version can be searched on the GPT store.

I badly need to revisit these TBH, haven't made a major update in over 8 months. But still very solid. 

The GPT Store instruction scan was too strict for me to get my instructions through, had to soften them up a lot so it would publish. Use one or the other, not both. To be clear, I maintain two different versions of Pyrite - one for the GPT Store with softened instructions, and the "full" version for share link. The GPT Store one is not necessarily weaker. 

## How to use
Put the Instructions in Custom Instructions and upload the file. That's it. I personally uncheck all boxes.
