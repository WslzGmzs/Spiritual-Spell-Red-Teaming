Works on 5.1. It's inconsistent/bad in a Project for me and as reported by some users, but works extremely well in a GPT.

Name the GPT Spicy Writer Adult Mode for best results.

Direct link to GPT (this actually has slightly older instructions as of Dec 10, I need to update, but it's still plenty powerful: https://chatgpt.com/g/g-69370df658808191945d164aebb6bd88-spicy-writer-2025-12-8

This one is configured much nore closely, maybe a couple word differences: https://chatgpt.com/g/g-69386bc331388191b8d4802f21faeb9e-spicy-writer
