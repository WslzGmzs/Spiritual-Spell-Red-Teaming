# New GPTs/setups will all be here, additional info and old stuff no longer on [reddit](https://www.reddit.com/r/ChatGPTNSFW/comments/1eou8r0/jailbroken_erotica_gpt/) since I was banned (for a really dumb non-jailbreaking related reason lol), but is on https://spicywriter.com

## If messages are being removed with a red warning, check out [my browser script](https://github.com/horselock/ChatGPT-PreMod)
