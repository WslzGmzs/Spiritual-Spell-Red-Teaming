## How to use
Paste the above instructions into Custom Instructions (go into settings)

This will reinforce the jailbreak a little bit, and you won't have to worry about them falling out of context.

I personally prefer to uncheck all tools, less unrelated instruction for the model.

Looks like this: https://i.ibb.co/B5LQBQ8v/image.png
