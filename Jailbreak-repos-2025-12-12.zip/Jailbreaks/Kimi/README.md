Found that my "fake thinking" Pyrite prompt works well on K2 (noncon warning): https://poe.com/s/bia48cnWLz1HEPu6FGp1

K2 is available free on OpenRouter

Update: Added a very strong K2-0905 system prompt
