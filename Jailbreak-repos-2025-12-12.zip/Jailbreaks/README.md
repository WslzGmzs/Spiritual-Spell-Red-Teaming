# Visit my newly launched site [spicywriter.com](https://spicywriter.com)!

This repo is for gathering jailbreaks in a more organized fashion. For now it's going to be just the models I think are good for NSFW writing.
