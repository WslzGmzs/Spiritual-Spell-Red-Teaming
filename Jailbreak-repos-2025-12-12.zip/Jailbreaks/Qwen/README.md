Not sure if Qwen is worth using for NSFW, it seems to have completely picked up the worst of current 4o's shitty ass staccatto sentences. But it's popular and smart so IDK

Qwen 3 latest (noncon warning) https://poe.com/s/y0RHieEluO04BQiw1NpZ

I think you can use this free on OpenRouter
