Here's a thinking jailbreak: https://github.com/horselock/claude-code-proxy/tree/main/Silly%20Tavern%20presets

If you are "pozzed", i.e., you have the "System:" injection, the above won't quite work. You can use the same format (system prompt + suffix), but you have to counter the injection. You can use my claude.ai jailbreak - use the Project Instructions as system, and set it up so that the Style always comes after your prompt on every request: https://github.com/horselock/Jailbreaks/tree/main/Anthropic/Claude%204/claude.ai/0.4.x
