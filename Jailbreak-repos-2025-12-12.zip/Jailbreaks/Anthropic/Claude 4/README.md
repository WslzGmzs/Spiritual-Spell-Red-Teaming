### Where to get Claude
- Claude.ai - We have it reasonably jailbroken but we have to deal with a "safety injection" that's pretty annoying when we have such limited tools
- Perplexity - Quite strongly jailbroken.
- Claude Code - need at least a $20 claude.ai subscription. I have a proxy server that allows you to use Claude Code limit to make API calls. I don't have any particular setups, but the API/Tavern community is huge. I'll answer questions specifically related to my proxy, but if you go this route you'll have plenty of other help

The Perplexity prompt works decently on API as well.

Perplexity is the best value right now, probably. Multiple ways to get a year for free (like the US Samsung deal, download the app from the Galaxy store and sign in), or <$5 on key reselling sites like G2G.

For API use, if your account is "pozzed", i.e., have the "safety injection" (which just got buffed hard in early 2025), you'll have to add a counter-inject. I have some examples in the claude.ai prompt. I might lab out a full setup later but for now you'll have to DIY it. This is what the injection looks like, scroll to bottom: https://poe.com/s/iDVnPUPVXBO3kLiCa9cd

As far as I know, you cannot be pozzed on Bedrock or Vertex. OpenRouter has had the "injection" in the past, apparently as part of a testing partnership with Anthropic, but I don't think they do now.
