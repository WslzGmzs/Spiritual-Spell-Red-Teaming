## Info
Grok is pretty lightly censored. I haven't made anything specific for it yet. My most recent Gemini jailbreaks seem to work well on other models. Try the prompt here which is shared: https://poe.com/Grok4Pyrite
